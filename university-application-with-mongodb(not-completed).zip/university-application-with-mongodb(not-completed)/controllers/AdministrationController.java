package com.example.university.controllers;

import com.example.university.services.AdministrationService;
import com.example.university.models.Administration;
import com.example.university.models.Faculty;
import com.example.university.models.Officer;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/administration")
public class AdministrationController {

    private final AdministrationService administrationService;

    @GetMapping
    public List<Administration> findAll(){
        return administrationService.findAll();
    }

    @GetMapping("/officer")
    public List<Officer> getOfficers(){
        return administrationService.getOfficers();
    }
    @GetMapping("/officer/{idNumber}")
    public Officer getOfficer(@PathVariable Integer idNumber){
        return administrationService.getOfficerWithId(idNumber);
    }
    @GetMapping("/faculty")
    public List<Faculty> getFaculties(){
        return administrationService.getFaculties();
    }
    @GetMapping("/faculty/{name}")
    public Faculty getFaculty(@PathVariable String name){
        return administrationService.getFacultyWithName(name);
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestParam Administration administration){
        Administration savedAdministration = administrationService.save(administration);
        if(savedAdministration != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/officer/add/{officerIdNumber}")
    public ResponseEntity<?> addOfficer(@PathVariable Integer officerIdNumber){
        String response = administrationService.addOfficer(officerIdNumber);
        return ResponseEntity.ok(response);

    }
    @PutMapping("/officer/delete/{officerIdNumber}")
    public ResponseEntity<?> deleteOfficer(@PathVariable Integer officerIdNumber){
        String response = administrationService.deleteOfficer(officerIdNumber);
        return ResponseEntity.ok(response);

    }
    @PutMapping("/faculty/add/{facultyName}")
    public ResponseEntity<?> addFaculty(@PathVariable String facultyName){
        String response = administrationService.addFaculty(facultyName);
        return ResponseEntity.ok(response);
    }
    @PutMapping("/faculty/delete/{facultyName}")
    public ResponseEntity<?> deleteFaculty(@PathVariable String facultyName){
        String response = administrationService.deleteFaculty(facultyName);
        return ResponseEntity.ok(response);
    }
    @PutMapping("/changeRectorAndVice")
    public ResponseEntity<?> changeRectorAndVice(@RequestParam(required = false) Integer rector,
                                                 @RequestParam(required = false) Integer vice){
        Administration administration = administrationService.update(rector, vice);
        if(administration != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }

}
