package com.example.university.controllers;

import com.example.university.models.AllCourses;
import com.example.university.services.AllCoursesService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/allcourses")
public class AllCoursesController {
    private final AllCoursesService allCoursesService;

    @GetMapping
    public List<AllCourses> findAll(){
        return allCoursesService.findAll();
    }
    @GetMapping("/{code}")
    public AllCourses findByCode(@PathVariable String code){
        return allCoursesService.findByCode(code);
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestParam AllCourses course){
        AllCourses savedAllCourses = allCoursesService.save(course);
        if(savedAllCourses != null){
            return ResponseEntity.ok().body("Success");
        }else{
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{code}")
    public AllCourses update(@PathVariable String code,
                                    @RequestParam(required = false) String name,
                                    @RequestParam(required = false) Float credit,
                                    @RequestParam(required = false) String department){
        return allCoursesService.update(code, name, credit, department);
    }
    @PutMapping("/{id}")
    public AllCourses update(@PathVariable String id,
                                    @RequestParam(required = false) String code){
        return allCoursesService.updateCode(id, code);
    }
    @DeleteMapping("/{code}")
    public ResponseEntity<?> delete(@PathVariable String code){
        String response = allCoursesService.delete(code);
        return ResponseEntity.ok().body(response);
    }

}
