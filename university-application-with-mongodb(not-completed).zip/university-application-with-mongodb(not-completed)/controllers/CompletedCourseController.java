package com.example.university.controllers;

import com.example.university.models.CompletedCourse;
import com.example.university.services.CompletedCourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/CompletedCourses")
public class CompletedCourseController {

    private final CompletedCourseService completedCourseService;

    @GetMapping
    public List<CompletedCourse> findAll(){
        return completedCourseService.findAll();
    }
    @GetMapping("/{id}")
    public CompletedCourse findById(@PathVariable String id){
        return completedCourseService.findById(id);
    }
    @PostMapping
    public ResponseEntity<?> save(@RequestBody CompletedCourse course){
        CompletedCourse savedCourse = completedCourseService.save(course);
        if(savedCourse != null){
            return ResponseEntity.ok().body("Success");
        }else{
            return ResponseEntity.badRequest().body("Failed");
        }
    }
    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable String id,
                                    @RequestParam String letterNote){
        CompletedCourse updated = completedCourseService.update(id, letterNote);
        if(updated != null){
            return ResponseEntity.ok().body("Success");
        }
        else{
            return ResponseEntity.badRequest().body("Failed");
        }
    }


}
