package com.example.university.controllers;

import com.example.university.models.Course;
import com.example.university.models.Student;
import com.example.university.services.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/course")
public class CourseController {

    private final CourseService courseService;

    @GetMapping
    public List<Course> findAll(){
        return courseService.findAll();
    }

    @GetMapping("/{code}")
    public Course findByCode(@PathVariable String code){
        return courseService.findByCode(code);
    }

    @GetMapping("/{code}/students")
    public List<Student> getStudents(@PathVariable String code){
        return courseService.getStudents(code);
    }

    @GetMapping("/{code}/GPAHigherThan/{gpa}")
    public List<Student> getStudentsByGpa(@PathVariable("code") String code,
                                          @PathVariable("gpa") Float gpa){
        return courseService.getStudentGPAGreaterThan(code, gpa);
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody Course course){
        Course saved = courseService.save(course);
        if(saved != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }

    @PutMapping("/{code}")
    public ResponseEntity<?> update(@PathVariable String code,
                                    @RequestParam(required = false) Integer instructorID){
        courseService.update(code, instructorID);
        return ResponseEntity.ok().body("Success");
    }

    @PutMapping("/{code}/add/{studentNumber}")
    public ResponseEntity<?> addStudent(@PathVariable("code") String code,
                                        @PathVariable("studentNumber") Integer studentNumber){
        String response = courseService.addStudent(code, studentNumber);
        return ResponseEntity.ok().body(response);
    }

    @DeleteMapping("/{code}")
    public ResponseEntity<?> delete(@PathVariable String code){
        String response = courseService.delete(code);
        return ResponseEntity.ok().body(response);
    }

}
