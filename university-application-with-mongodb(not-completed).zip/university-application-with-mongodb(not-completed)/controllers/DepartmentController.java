package com.example.university.controllers;

import com.example.university.models.Department;
import com.example.university.services.DepartmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/department")
public class DepartmentController {

    private final DepartmentService departmentService;

    @GetMapping
    public List<Department> findAll() {
        return departmentService.findAll();
    }

    @GetMapping("/{name}")
    public Department findByName(@PathVariable String name) {
        return departmentService.findByName(name);
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody Department department) {
        Department saved = departmentService.save(department);
        if (saved != null) {
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }

    @PutMapping("/{name}")
    public ResponseEntity<?> update(@PathVariable String name,
                                    @RequestParam(required = false) Integer head,
                                    @RequestParam(required = false) Integer viceHead) {
        Department updated = departmentService.update(name, head, viceHead);
        if (updated != null) {
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }

    @DeleteMapping("/{name}")
    public ResponseEntity<?> delete(@PathVariable String name) {
        String response = departmentService.delete(name);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/{departmentName}/addInstructor/{instructorIDNumber}")
    public ResponseEntity<?> addInstructor(@PathVariable String departmentName,
                                           @PathVariable Integer instructorIDNumber) {
        String response = departmentService.addInstructor(departmentName, instructorIDNumber);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/{departmentName}/addStudent/{studentNumber}")
    public ResponseEntity<?> addStudent(@PathVariable String departmentName,
                                        @PathVariable Integer studentNumber) {
        String response = departmentService.addStudent(departmentName, studentNumber);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/{departmentName}/addOfficer/{officerID}")
    public ResponseEntity<?> addOfficer(@PathVariable String departmentName,
                                        @PathVariable Integer officerID) {
        String response = departmentService.addOfficer(departmentName, officerID);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/{departmentName}/addCourse/{courseCode}")
    public ResponseEntity<?> addCourse(@PathVariable String departmentName,
                                       @PathVariable String courseCode) {
        String response = departmentService.addCourse(departmentName, courseCode);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/{departmentName}/addActiveCourse/{courseCode}")
    public ResponseEntity<?> addActiveCourse(@PathVariable String departmentName,
                                             @PathVariable String courseCode) {
        String response = departmentService.addActiveCourse(departmentName, courseCode);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/{departmentName}/removeInstructor/{instructorIDNumber}")
    public ResponseEntity<?> removeInstructor(@PathVariable String departmentName,
                                           @PathVariable Integer instructorIDNumber) {
        String response = departmentService.removeInstructor(departmentName, instructorIDNumber);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/{departmentName}/removeStudent/{studentNumber}")
    public ResponseEntity<?> removeStudent(@PathVariable String departmentName,
                                        @PathVariable Integer studentNumber) {
        String response = departmentService.removeStudent(departmentName, studentNumber);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/{departmentName}/removeOfficer/{officerID}")
    public ResponseEntity<?> removeOfficer(@PathVariable String departmentName,
                                        @PathVariable Integer officerID) {
        String response = departmentService.removeOfficer(departmentName, officerID);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/{departmentName}/removeCourse/{courseCode}")
    public ResponseEntity<?> removeCourse(@PathVariable String departmentName,
                                       @PathVariable String courseCode) {
        String response = departmentService.removeCourse(departmentName, courseCode);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/{departmentName}/removeActiveCourse/{courseCode}")
    public ResponseEntity<?> removeActiveCourse(@PathVariable String departmentName,
                                             @PathVariable String courseCode) {
        String response = departmentService.removeActiveCourse(departmentName, courseCode);
        return ResponseEntity.ok().body(response);
    }





}
