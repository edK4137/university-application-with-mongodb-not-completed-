package com.example.university.controllers;


import com.example.university.models.*;
import com.example.university.services.FacultyService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/faculty")
public class FacultyController {

    private final FacultyService facultyService;

    @GetMapping
    public List<Faculty> findAll(){
        return facultyService.findAll();
    }
    @GetMapping("/{facultyName}")
    public Faculty findByName(@PathVariable String facultyName){
        return facultyService.findByName(facultyName);
    }
    @PostMapping
    public ResponseEntity<?> save(@RequestBody Faculty faculty){
        Faculty saving = facultyService.save(faculty);
        if(saving != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }
    @PutMapping("/{facultyName}/change")
    public ResponseEntity<?> update(@PathVariable String facultyName,
                                    @RequestParam(required = false) Integer dean,
                                    @RequestParam(required = false) Integer viceDean){
        Faculty updated = facultyService.update(facultyName, dean, viceDean);
        if(updated != null){
            return ResponseEntity.ok().body("Success");
        }else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }
    @PutMapping("/{facultyId}/changeName/{newFacultyName}")
    public ResponseEntity<?> updateFacultyName(@PathVariable String facultyId,
                                               @PathVariable String newFacultyName){
        Faculty faculty = facultyService.updateName(facultyId, newFacultyName);
        if(faculty != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }
    @DeleteMapping("/{facultyName}")
    public ResponseEntity<?> delete(@PathVariable String facultyName){
        String response = facultyService.delete(facultyName);
        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/{facultyName}/departments")
    public List<Department> getDepartments(@PathVariable String facultyName){
        return facultyService.getDepartments(facultyName);
    }

    @GetMapping("/{facultyName}/instructors")
    public List<Instructor> getInstructors(@PathVariable String facultyName){
        return facultyService.getInstructors(facultyName);
    }
    @GetMapping("/{facultyName}/officers")
    public List<Officer> getOfficers(@PathVariable String facultyName){
        return facultyService.getOfficers(facultyName);
    }
    @GetMapping("/{facultyName}/students")
    public List<Student> getStudents(@PathVariable String facultyName){
        return facultyService.getStudents(facultyName);
    }

    @PutMapping("/{facultyName}/addDepartment/{departmentName}")
    public ResponseEntity<?> addDepartment(@PathVariable String facultyName,
                                           @PathVariable String departmentName){
        String response = facultyService.addDepartment(facultyName, departmentName);
        return ResponseEntity.ok().body(response);
    }
    @PutMapping("/{facultyName}/addInstructor/{instructorID}")
    public ResponseEntity<?> addInstructor(@PathVariable String facultyName,
                                           @PathVariable Integer instructorID){
        String response = facultyService.addInstructor(facultyName, instructorID);
        return ResponseEntity.ok().body(response);
    }
    @PutMapping("/{facultyName}/addOfficer/{officerID}")
    public ResponseEntity<?> addOfficer(@PathVariable String facultyName,
                                           @PathVariable Integer officerID){
        String response = facultyService.addOfficer(facultyName, officerID);
        return ResponseEntity.ok().body(response);
    }
    @PutMapping("/{facultyName}/addStudent/{studentNumber}")
    public ResponseEntity<?> addStudent(@PathVariable String facultyName,
                                        @PathVariable Integer studentNumber){
        String response = facultyService.addStudent(facultyName, studentNumber);
        return ResponseEntity.ok().body(response);
    }

    @PutMapping("/{facultyName}/removeDepartment/{departmentName}")
    public ResponseEntity<?> removeDepartment(@PathVariable String facultyName,
                                           @PathVariable String departmentName){
        String response = facultyService.removeDepartment(facultyName, departmentName);
        return ResponseEntity.ok().body(response);
    }
    @PutMapping("/{facultyName}/removeInstructor/{instructorID}")
    public ResponseEntity<?> removeInstructor(@PathVariable String facultyName,
                                           @PathVariable Integer instructorID){
        String response = facultyService.removeInstructor(facultyName, instructorID);
        return ResponseEntity.ok().body(response);
    }
    @PutMapping("/{facultyName}/removeOfficer/{officerID}")
    public ResponseEntity<?> removeOfficer(@PathVariable String facultyName,
                                           @PathVariable Integer officerID){
        String response = facultyService.removeOfficer(facultyName, officerID);
        return ResponseEntity.ok().body(response);
    }
    @PutMapping("/{facultyName}/removeStudent/{studentNumber}")
    public ResponseEntity<?> removeStudent(@PathVariable String facultyName,
                                        @PathVariable Integer studentNumber){
        String response = facultyService.removeStudent(facultyName, studentNumber);
        return ResponseEntity.ok().body(response);
    }



}