package com.example.university.controllers;

import com.example.university.models.CompletedCourse;
import com.example.university.models.GraduatedStudent;
import com.example.university.services.GraduatedStudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/graduatedStudent")
public class GraduatedStudentController {

    private final GraduatedStudentService graduatedStudentService;
    @GetMapping
    List<GraduatedStudent> findAll(){
        return graduatedStudentService.findAll();
    }
    @GetMapping("/{studentNumber}")
    GraduatedStudent findByName(@PathVariable Integer studentNumber){
        return graduatedStudentService.findByNumber(studentNumber);
    }
    @PostMapping
    public ResponseEntity<?> save(@RequestBody GraduatedStudent graduatedStudent){
        GraduatedStudent saving = graduatedStudentService.save(graduatedStudent);
        if(saving != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }
    @GetMapping("/{studentNumber}/courses")
    public List<CompletedCourse> getStudentCourses(@PathVariable Integer studentNumber){
        return graduatedStudentService.getCourses(studentNumber);
    }

}
