package com.example.university.controllers;


import com.example.university.models.AllCourses;
import com.example.university.models.Course;
import com.example.university.models.Instructor;
import com.example.university.services.InstructorService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/instructor")
public class InstructorController {

    private final InstructorService instructorService;

    @GetMapping
    public List<Instructor> findAll() {
        return instructorService.findAll();
    }

    @GetMapping("/{idNumber}")
    public Instructor findByIdNumber(@PathVariable Integer idNumber) {
        return instructorService.findByIdNumber(idNumber);
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody Instructor instructor) {
        Instructor saving = instructorService.save(instructor);
        if (saving != null) {
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }

    @PutMapping("/{idNumber}")
    public ResponseEntity<?> update(@PathVariable Integer idNumber,
                                 @RequestParam(required = false) String name,
                                 @RequestParam(required = false) String department,
                                 @RequestParam(required = false) String email) {
        Instructor updated = instructorService.update(idNumber, name, department, email);
        if(updated != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }
    @PutMapping("/{id}/changeNumber/{idNumber}")
    public ResponseEntity<?> updateIDNumber(@PathVariable String id,
                                            @PathVariable Integer idNumber){
        Instructor updated = instructorService.updateIDNumber(id, idNumber);
        if(updated != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }
    @DeleteMapping("/{idNumber}")
    public ResponseEntity<?> delete(@PathVariable Integer idNumber){
        String response = instructorService.delete(idNumber);
        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/{idNumber}/courses")
    public List<Course> getCourses(@PathVariable Integer idNumber){
        return instructorService.getCourses(idNumber);
    }
    @GetMapping("/{idNumber}/allCourses")
    public List<AllCourses> getAllCourses(@PathVariable Integer idNumber){
        return instructorService.getAllCourses(idNumber);
    }

    @PutMapping("/{idNumber}/addCourse/{courseCode}")
    public ResponseEntity<?> addCourse(@PathVariable Integer idNumber,
                                       @PathVariable String courseCode){
        String response = instructorService.addCourse(idNumber, courseCode);
        return ResponseEntity.ok().body(response);
    }
    @PutMapping("/{idNumber}/addToAllCourses/{courseCode}")
    public ResponseEntity<?> addAllCourses(@PathVariable Integer idNumber,
                                           @PathVariable String courseCode){
        String response = instructorService.addCourseCanTeach(idNumber, courseCode);
        return ResponseEntity.ok().body(response);
    }
    @PutMapping("/{idNumber}/removeCourse/{courseCode}")
    public ResponseEntity<?> removeCourse(@PathVariable Integer idNumber,
                                        @PathVariable String courseCode){
        String response = instructorService.removeCourse(idNumber, courseCode);
        return ResponseEntity.ok().body(response);
    }
    @PutMapping("/{idNumber}/removeFromAllCourses/{courseCode}")
    public ResponseEntity<?> removeFromAllCourses(@PathVariable Integer idNumber,
                                       @PathVariable String courseCode){
        String response = instructorService.removeCourseCanTeach(idNumber, courseCode);
        return ResponseEntity.ok().body(response);
    }

}
