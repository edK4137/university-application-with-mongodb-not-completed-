package com.example.university.controllers;

import com.example.university.models.Officer;
import com.example.university.services.OfficerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/officer")
public class OfficerController {

    private final OfficerService officerService;

    @GetMapping
    public List<Officer> findAll() {
        return officerService.findAll();
    }

    @GetMapping("/{idNumber}")
    public Officer findByIdNumber(@PathVariable Integer idNumber) {
        return officerService.findByIdNumber(idNumber);
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody Officer officer) {
        Officer saving = officerService.save(officer);
        if (saving != null) {
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }

    @PutMapping("/{idNumber}")
    public ResponseEntity<?> update(@PathVariable Integer idNumber,
                                    @RequestParam(required = false) String name,
                                    @RequestParam(required = false) String department,
                                    @RequestParam(required = false) String title,
                                    @RequestParam(required = false) String email) {
        Officer updated = officerService.update(idNumber, name, department, title, email);
        if(updated != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }

    @PutMapping("/{id}/changeIDNumber/{idNumber}")
    public ResponseEntity<?> updateIDNumber(@PathVariable String id,
                                            @PathVariable Integer idNumber){
        Officer updated = officerService.updateIdNumber(id, idNumber);
        if(updated != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }
    @DeleteMapping("/{idNumber}")
    public ResponseEntity<?> delete(@PathVariable Integer idNumber){
        String response = officerService.delete(idNumber);
        return ResponseEntity.ok().body(response);
    }


}
