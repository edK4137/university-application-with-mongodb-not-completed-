package com.example.university.controllers;

import com.example.university.models.Semester;
import com.example.university.services.SemesterService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/semester")
public class SemesterController {

    private final SemesterService semesterService;

    @GetMapping
    public List<Semester> findAll(){
        return semesterService.findAll();
    }
    @GetMapping("/{semesterName}")
    public Semester findByName(String semesterName){
        return semesterService.findByName(semesterName);
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody Semester semester){
        Semester saving = semesterService.save(semester);
        if(saving != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }

    @PutMapping("/{semesterName}/endSemester")
    public ResponseEntity<?> endSemester(@PathVariable String semesterName){
        String response = semesterService.endSemester(semesterName);
        return ResponseEntity.ok().body(response);
    }

}
