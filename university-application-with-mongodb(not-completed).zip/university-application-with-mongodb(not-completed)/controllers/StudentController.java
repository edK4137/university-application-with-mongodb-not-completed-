package com.example.university.controllers;

import com.example.university.models.CompletedCourse;
import com.example.university.models.Course;
import com.example.university.models.Student;
import com.example.university.services.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/student")
public class StudentController {

    private final StudentService studentService;

    @GetMapping
    public List<Student> findAll(){
        return studentService.findAll();
    }

    @GetMapping("/{studentNumber}")
    public Student findByNumber(@PathVariable Integer studentNumber){
        return studentService.findByNumber(studentNumber);
    }

    @PostMapping
    public ResponseEntity<?> save(@RequestBody Student student){
        Student saving = studentService.save(student);
        if(saving != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }

    @PutMapping("/{studentNumber}")
    public ResponseEntity<?> update(@PathVariable Integer studentNumber,
                                    @RequestParam(required = false) String name,
                                    @RequestParam(required = false) String email){
        Student updated = studentService.update(studentNumber, name, email);
        if(updated != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }
    @PutMapping("/{studentID}/changeNumber/{studentNumber}")
    public ResponseEntity<?> updateNumber(@PathVariable String studentID,
                                          @PathVariable Integer studentNumber){
        Student updated = studentService.updateNumber(studentID, studentNumber);
        if(updated != null){
            return ResponseEntity.ok().body("Success");
        } else {
            return ResponseEntity.badRequest().body("Failed");
        }
    }
    @DeleteMapping("/{studentNumber}")
    public ResponseEntity<?> delete(@PathVariable Integer studentNumber){
        String response = studentService.delete(studentNumber);
        return ResponseEntity.ok().body(response);
    }

    @GetMapping("/{studentNumber}/courses")
    public List<Course> getCourses(@PathVariable Integer studentNumber){
        return studentService.getCourses(studentNumber);
    }
    @GetMapping("/{studentNumber}/completedCourses")
    public List<CompletedCourse> getCompletedCurses(@PathVariable Integer studentNumber){
        return studentService.getCompletedCourses(studentNumber);
    }

    @PutMapping("/{studentNumber}/addCompletedCourse/{courseCode}")
    public ResponseEntity<?> addCompletedCourse(@PathVariable Integer studentNumber,
                                                @PathVariable String courseCode){
        String response = studentService.addCompletedCourse(studentNumber, courseCode);
        return ResponseEntity.ok().body(response);
    }

}
