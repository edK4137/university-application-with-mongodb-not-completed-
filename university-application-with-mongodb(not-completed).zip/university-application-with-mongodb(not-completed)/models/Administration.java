package com.example.university.models;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "Administration")
public class Administration {
    @Id
    private String id;
    private Integer name;
    private Integer rector;         // Instructor.idNumber
    private Integer viceRector;     // Instructor.idNumber
    private List<Integer> officers; // Officer.idNumber
    private List<String> faculties;

}
