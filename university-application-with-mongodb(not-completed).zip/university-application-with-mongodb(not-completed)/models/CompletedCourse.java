package com.example.university.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "CompletedCourse")
public class CompletedCourse {
    @Id
    private String id;
    private String code;        // course.code
    private String name;        // course.name
    private Float credit;     // course.credit
    private String studentID;   // student.id (karışmaması için id'yle tutuyoruz)
    private String letterNote;
    private Float note;
}
