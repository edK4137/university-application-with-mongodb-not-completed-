package com.example.university.models;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "Course")
public class Course {
    @Id
    private String id;
    private String code;
    private String name;
    private Float credit;
    private String semester;        // semester.name
    private Integer instructor;     // instructor.idNumber
    private String department;      // department.name
    private List<Integer> students; // student.number
}
