package com.example.university.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "Department")
public class Department {
    @Id
    private String id;
    private String name;
    private String facultyName;             // faculty.name
    private Integer headOf;                 // instructor.id
    private Integer viceHeadOf;             // instructor.id
    private List<Integer> instructors;      // instructor.id
    private List<Integer> students;         // student.number
    private List<Integer> graduatedStudent; // graduatedStudent.number
    private List<Integer> officers;         // officer.idNumber
    private List<AllCourses> courses;       // AllCourses
    private List<String> activeCourses;     // course.courseCode

}
