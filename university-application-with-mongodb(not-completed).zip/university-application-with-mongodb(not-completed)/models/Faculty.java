package com.example.university.models;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "Faculty")
public class Faculty {
    @Id
    private String id;
    private String name;
    private Integer dean;               // instructor.id
    private Integer viceDean;           // instructor.id
    private List<String> departments;   // department.name
    private List<Integer> instructors;  // instructor.idNumber
    private List<Integer> officers;     // officer.idNumber
    private List<Integer> students;     // Student.number
}
