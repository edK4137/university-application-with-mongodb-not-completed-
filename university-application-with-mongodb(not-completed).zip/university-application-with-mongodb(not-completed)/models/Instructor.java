package com.example.university.models;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "Instructor")

public class Instructor {
    @Id
    private String id;
    private Integer idNumber;
    private String name;
    private String department;              // department.name
    private String email;
    private List<String> courses;           // course.code
    private List<String> coursesCanTeach;   // AllCourse.code
}
