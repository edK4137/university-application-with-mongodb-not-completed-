package com.example.university.models;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "Note")
public class Note {
    @Id
    private String id;
    private Integer studentNumber;
    private String courseCode;
    private String letterNote;
    private Float courseNote;

}
