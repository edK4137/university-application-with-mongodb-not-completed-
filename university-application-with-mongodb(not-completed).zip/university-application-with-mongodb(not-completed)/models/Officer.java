package com.example.university.models;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "officer")
public class Officer {
    @Id
    private String id;
    private Integer idNumber;
    private String name;
    private String department; // department.name
    private String title;
    private String email;
}
