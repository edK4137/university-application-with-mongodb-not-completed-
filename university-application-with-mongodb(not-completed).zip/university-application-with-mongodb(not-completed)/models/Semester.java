package com.example.university.models;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "Semester")
public class Semester {
    @Id
    private String id;
    private String name;            // 2018.Spring ya da 2018.Autumn gibi bir formatta tutulması gerek
    private LocalDate startDate;
    private LocalDate endTime;
    private List<CompletedCourse> courses;   // Course.code  &   eğer aktif dönemse serviste course.code ' a göre
                                                // değilse direkt listeyi döndür
    private boolean isCompleted;

}
