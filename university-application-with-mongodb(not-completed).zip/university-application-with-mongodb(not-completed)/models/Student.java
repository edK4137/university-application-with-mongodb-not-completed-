package com.example.university.models;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Document(collection = "Student")
public class Student {
    @Id
    private String id;
    private Integer number;
    private String name;
    private String department;              // department.name
    private String email;
    private Float gpa;
    private Integer semester;
    private List<String> enrolledCourses;   // course.code
    private List<String> completedCourses;  // completedCourse.id

}
