package com.example.university.repositories;

import com.example.university.models.AllCourses;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface AllCoursesRepository extends MongoRepository<AllCourses, String> {
    AllCourses findByCode(String code);
    void deleteByCode(String code);
    boolean existsByCode(String code);
}
