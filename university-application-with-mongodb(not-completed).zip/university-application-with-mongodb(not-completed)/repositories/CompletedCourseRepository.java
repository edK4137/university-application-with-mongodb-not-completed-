package com.example.university.repositories;

import com.example.university.models.CompletedCourse;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CompletedCourseRepository extends MongoRepository<CompletedCourse, String> {
}
