package com.example.university.repositories;

import com.example.university.models.Course;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface CourseRepository extends MongoRepository<Course, String> {
    Course findByCode(String code);
    void deleteByCode(String code);
    boolean existsByCode(String code);
}
