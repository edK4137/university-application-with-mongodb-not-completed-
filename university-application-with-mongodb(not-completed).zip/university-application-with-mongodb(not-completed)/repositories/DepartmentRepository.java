package com.example.university.repositories;

import com.example.university.models.Department;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DepartmentRepository extends MongoRepository<Department, String> {
    Department findByName(String name);
    void deleteByName(String name);
    boolean existsByName(String name);
}
