package com.example.university.repositories;

import com.example.university.models.Faculty;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface FacultyRepository extends MongoRepository<Faculty, String> {
    Faculty findByName(String name);
    void deleteByName(String name);
    boolean existsByName(String name);
}
