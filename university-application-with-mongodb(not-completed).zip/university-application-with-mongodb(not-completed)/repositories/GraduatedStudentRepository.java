package com.example.university.repositories;

import com.example.university.models.GraduatedStudent;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface GraduatedStudentRepository extends MongoRepository<GraduatedStudent, String> {
    GraduatedStudent findByNumber(Integer number);
    void deleteByNumber(Integer number);
    boolean existsAllByNumber(Integer number);
}
