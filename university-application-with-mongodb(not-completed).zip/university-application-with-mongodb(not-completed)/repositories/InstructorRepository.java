package com.example.university.repositories;

import com.example.university.models.Instructor;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface InstructorRepository extends MongoRepository<Instructor, String> {
    Instructor findByIdNumber(Integer number);
    void deleteByIdNumber(Integer number);
    boolean existsByIdNumber(Integer number);
}
