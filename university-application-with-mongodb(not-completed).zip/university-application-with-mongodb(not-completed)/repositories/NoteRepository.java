package com.example.university.repositories;

import com.example.university.models.Note;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface NoteRepository extends MongoRepository<Note, String> {
    List<Note> findAllByStudentNumber(Integer studentNumber);
    Note findByStudentNumberAndCourseCode(Integer studentNumber, String code);

}
