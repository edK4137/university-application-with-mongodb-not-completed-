package com.example.university.repositories;

import com.example.university.models.Officer;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface OfficerRepository extends MongoRepository<Officer, String> {
    Officer findByIdNumber(Integer number);
    void deleteByIdNumber(Integer number);
    boolean existsByIdNumber(Integer number);
}
