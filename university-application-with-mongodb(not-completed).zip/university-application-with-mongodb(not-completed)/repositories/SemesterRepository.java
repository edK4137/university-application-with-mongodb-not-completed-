package com.example.university.repositories;

import com.example.university.models.Semester;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface SemesterRepository extends MongoRepository<Semester, String> {
    Semester findByName(String name);
    void deleteByName(String name);
    boolean existsByName(String name);
}
