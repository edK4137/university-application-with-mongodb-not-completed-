package com.example.university.repositories;

import com.example.university.models.Student;
import org.springframework.data.mongodb.repository.MongoRepository;
public interface  StudentRepository extends MongoRepository<Student, String> {
    Student findByNumber(Integer number);
    void deleteByNumber(Integer number);
    boolean existsByNumber(Integer number);

}
