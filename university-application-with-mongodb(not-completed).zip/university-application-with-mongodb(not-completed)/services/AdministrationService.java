package com.example.university.services;


import com.example.university.models.Administration;
import com.example.university.models.Faculty;
import com.example.university.models.Officer;
import com.example.university.repositories.AdministrationRepository;
import com.example.university.repositories.FacultyRepository;
import com.example.university.repositories.InstructorRepository;
import com.example.university.repositories.OfficerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AdministrationService {
    private final AdministrationRepository administrationRepository;
    private final InstructorRepository instructorRepository;
    private final OfficerRepository officerRepository;
    private final FacultyRepository facultyRepository;

    public List<Administration> findAll() {
        return administrationRepository.findAll();
    }

    public Administration save(Administration administration) {
        Administration saving = (Administration.builder()
                .id(UUID.randomUUID().toString())
                .name(administration.getName())
                .rector(administration.getRector())
                .viceRector(administration.getViceRector())
                .officers(administration.getOfficers())
                .faculties(administration.getFaculties()))
                .build();
        return administrationRepository.save(saving);
    }

    @Transactional
    public Administration update(Integer rector, Integer viceRector) {


        Administration administration = administrationRepository.findByName("Recotrate");

        if (rector != null && rector > 0 && !Objects.equals(rector, administration.getRector())) {
            administration.setRector(rector);
        }
        if (viceRector != null && viceRector > 0 && !Objects.equals(viceRector, administration.getViceRector())) {
            administration.setViceRector(viceRector);
        }


        return administrationRepository.save(administration);
    }

    public List<Officer> getOfficers() {
        ArrayList<Officer> officers = new ArrayList<>();
        List<Integer> officerIDNumber = administrationRepository.findByName("Rectorate").getOfficers();
        officerIDNumber.sort(Integer::compareTo);
        for (Integer i : officerIDNumber) {
            officers.add(officerRepository.findByIdNumber(i));
        }
        return officers;

    }

    public Officer getOfficerWithId(Integer idNumber){
        return officerRepository.findByIdNumber(idNumber);
    }

    public List<Faculty> getFaculties() {
        ArrayList<Faculty> faculties = new ArrayList<>();
        List<String> officerIDNumber = administrationRepository.findByName("Rectorate").getFaculties();
        officerIDNumber.sort(String::compareTo);
        for (String i : officerIDNumber) {
            faculties.add(facultyRepository.findByName(i));
        }
        return faculties;
    }
    public Faculty getFacultyWithName(String name){
        return facultyRepository.findByName(name);
    }

    public String addOfficer(Integer officerIdNumber) {
        if (!officerRepository.existsByIdNumber(officerIdNumber)) {
            return "Officer with ID " + officerIdNumber + " is not exist.";
        }

        Officer officer = officerRepository.findByIdNumber(officerIdNumber);
        officer.setDepartment("Rectorate");

        Administration admin = administrationRepository.findByName("Rectorate");
        List<Integer> officers = admin.getOfficers();
        officers.add(officerIdNumber);
        admin.setOfficers(officers);

        administrationRepository.save(admin);
        officerRepository.save(officer);

        return "Officer with ID " + officerIdNumber
                + "is successfully changed its department to Rectorate";

    }

    public String addFaculty(String facultyName) {
        if (!facultyRepository.existsByName(facultyName)) {
            return "" + facultyName + " is not exist.";
        }

        Administration admin = administrationRepository.findByName("Rectorate");
        List<String> faculties = admin.getFaculties();
        faculties.add(facultyName);
        admin.setFaculties(faculties);

        administrationRepository.save(admin);
        return "" + facultyName + " is successfully added to university system.";

    }

    public String deleteOfficer(Integer officerIDNum) {
        if (!officerRepository.existsByIdNumber(officerIDNum)) {
            return "Officer with ID " + officerIDNum + " is not exist.";
        }

        Officer officer = officerRepository.findByIdNumber(officerIDNum);
        officer.setDepartment("NONE");

        Administration admin = administrationRepository.findByName("Rectorate");
        List<Integer> officers = admin.getOfficers();
        officers.remove(officerIDNum);
        admin.setOfficers(officers);

        officerRepository.save(officer);
        administrationRepository.save(admin);

        return "Officer with ID " + officerIDNum + " is successfully departed from Rectorate";
    }

    public String deleteFaculty(String facultyName) {
        if (!facultyRepository.existsByName(facultyName)) {
            return "" + facultyName + " is not exist";
        }
        Administration admin = administrationRepository.findByName("Rectorate");
        List<String> faculties = admin.getFaculties();
        if (faculties.remove(facultyName)) {
            admin.setFaculties(faculties);
            administrationRepository.save(admin);
            return "" + facultyName + " is successfully deleted from university system.";
        }
        return "" + facultyName + " is not found. Probably, it's never been added yet.";
    }

}
