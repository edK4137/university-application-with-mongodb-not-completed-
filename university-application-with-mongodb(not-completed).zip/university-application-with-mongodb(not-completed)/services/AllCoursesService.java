package com.example.university.services;

import com.example.university.models.AllCourses;
import com.example.university.models.Department;
import com.example.university.repositories.AllCoursesRepository;
import com.example.university.repositories.DepartmentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AllCoursesService {
    private final AllCoursesRepository allCoursesRepository;
    private final DepartmentRepository departmentRepository;


    public List<AllCourses> findAll() {
        return allCoursesRepository.findAll();
    }

    public AllCourses findByCode(String code) {
        return allCoursesRepository.findByCode(code);
    }

    public AllCourses save(AllCourses allCourses) {
        if (allCoursesRepository.existsByCode(allCourses.getCode())) {
            throw new IllegalStateException("This course already exists.");
        }
        Department department = departmentRepository.findByName(allCourses.getDepartment());
        List<AllCourses> departmentAllCourses = department.getCourses();

        AllCourses saving = AllCourses.builder()
                .id(UUID.randomUUID().toString())
                .code(allCourses.getCode())
                .name(allCourses.getName())
                .credit(allCourses.getCredit())
                .build();

        departmentAllCourses.add(saving);
        department.setCourses(departmentAllCourses);
        departmentRepository.save(department);

        return allCoursesRepository.save(saving);
    }

    @Transactional
    public AllCourses update(String code, String name,
                             Float credit, String department) {
        if (!allCoursesRepository.existsByCode(code)) {
            throw new IllegalStateException("This course with code " + code + " does not exist.");
        }
        AllCourses course = allCoursesRepository.findByCode(code);
        Department department1 = departmentRepository.findByName(course.getDepartment());
        List<AllCourses> allCourses = department1.getCourses();
        allCourses.remove(course);

        if (name != null && name.length() > 0 && !name.equals(course.getName())) {
            course.setName(name);
        }

        if (credit != null && credit > 0F && !credit.equals(course.getCredit())) {
            course.setCredit(credit);
        }

        if (department != null && department.length() > 0 && department.equals(course.getDepartment())) {
            course.setDepartment(department);
            Department departmentUpdated = departmentRepository.findByName(department);
            allCourses = departmentUpdated.getCourses();
            allCourses.add(course);
            departmentUpdated.setCourses(allCourses);
            departmentRepository.save(departmentUpdated);
        } else {
            allCourses.add(course);
            department1.setCourses(allCourses);
            departmentRepository.save(department1);
        }


        return allCoursesRepository.save(course);
    }

    @Transactional
    public AllCourses updateCode(String id, String code) {
        if (!allCoursesRepository.existsById(id)) {
            throw new IllegalStateException("Course with giving id does not exist.");
        }
        AllCourses course = allCoursesRepository.findById(id).orElseThrow();

        Department department = departmentRepository.findByName(course.getDepartment());
        List<AllCourses> allCourses = department.getCourses();
        allCourses.remove(course);

        if (code != null && code.length() > 0 && !code.equals(course.getCode())) {
            course.setCode(code);
        }

        allCourses.add(course);
        department.setCourses(allCourses);
        departmentRepository.save(department);

        return allCoursesRepository.save(course);
    }

    public String delete(String code) {
        if (allCoursesRepository.existsByCode(code)) {
            AllCourses course = allCoursesRepository.findByCode(code);

            Department department = departmentRepository.findByName(course.getDepartment());
            List<AllCourses> allCourses = department.getCourses();
            allCourses.remove(course);
            department.setCourses(allCourses);
            departmentRepository.save(department);

            allCoursesRepository.deleteByCode(code);
            return "Course with code " + code + " deleted successfully.";
        }
        return "Course with code " + code + " is not exist.";
    }

}
