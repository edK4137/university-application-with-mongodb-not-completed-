package com.example.university.services;


import com.example.university.models.AllCourses;
import com.example.university.models.CompletedCourse;
import com.example.university.models.Student;
import com.example.university.repositories.AllCoursesRepository;
import com.example.university.repositories.CompletedCourseRepository;
import com.example.university.repositories.CourseRepository;
import com.example.university.repositories.StudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class CompletedCourseService {
    private final CompletedCourseRepository completedCourseRepository;
    private final StudentRepository studentRepository;
    private final AllCoursesRepository allCoursesRepository;
    private final CourseRepository courseRepository;

    public List<CompletedCourse> findAll(){
        return completedCourseRepository.findAll();
    }

    public CompletedCourse findById(String id){
        if(!completedCourseRepository.existsById(id)){
            throw new IllegalStateException("ID is not found.");
        }
        return completedCourseRepository.findById(id).orElseThrow();
    }

    public CompletedCourse save(CompletedCourse completedCourse){

        CompletedCourse saving = CompletedCourse.builder()
                .id(UUID.randomUUID().toString())
                .code(completedCourse.getCode())
                .name(completedCourse.getName())
                .credit(completedCourse.getCredit())
                .studentID(completedCourse.getStudentID())
                .letterNote(completedCourse.getLetterNote())
                .note(calculateNote(completedCourse.getCode(),completedCourse.getLetterNote()))
                .build();

        Student student = studentRepository.findById(saving.getStudentID()).orElseThrow();
        List<String> completedCourses = student.getCompletedCourses();
        completedCourses.add(saving.getId());
        student.setCompletedCourses(completedCourses);
        studentRepository.save(student);

        return completedCourseRepository.save(saving);
    }

    @Transactional
    public CompletedCourse update(String id, String letterNote){
        if(!completedCourseRepository.existsById(id)){
            throw new IllegalStateException("Does not exist");
        }
        CompletedCourse course = completedCourseRepository.findById(id).orElseThrow();

        if(letterNote != null && letterNote.length() > 0 && !letterNote.equals(course.getLetterNote())){
            course.setLetterNote(letterNote);
            course.setNote(calculateNote(course.getCode(), letterNote));
        }


        return completedCourseRepository.save(course);
    }

    private Float calculateNote(String courseCode, String letterNote){
        AllCourses course = allCoursesRepository.findByCode(courseCode);
        Float credit = course.getCredit();
        return switch (letterNote) {
            case "AA" -> credit * 4F;
            case "BA" -> credit * 3.5F;
            case "BB" -> credit * 3F;
            case "CB" -> credit * 2.5F;
            case "CC" -> credit * 2F;
            case "DC" -> credit * 1.5F;
            case "DD" -> credit * 1F;
            case "FD" -> credit * 0.5F;
            case "FF" -> credit * 0F;
            default -> 0F;
        };

    }

}
