package com.example.university.services;

import com.example.university.models.*;
import com.example.university.repositories.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class CourseService {
    private final CourseRepository courseRepository;
    private final DepartmentRepository departmentRepository;
    private final StudentRepository studentRepository;
    private final InstructorRepository instructorRepository;
    private final NoteRepository noteRepository;
    private final AllCoursesRepository allCoursesRepository;
    private final SemesterRepository semesterRepository;

    public List<Course> findAll() {
        return courseRepository.findAll();
    }

    public Course findByCode(String code) {
        return courseRepository.findByCode(code);
    }

    public Course save(Course course) {
        AllCourses mainCourse = allCoursesRepository.findByCode(course.getCode());

        Instructor instructor = instructorRepository.findByIdNumber(course.getInstructor());
        List<String> courses = instructor.getCourses();
        if(!courses.contains(course.getCode())){
            courses.add(course.getCode());
        }
        instructorRepository.save(instructor);


        Course saving = Course.builder()
                .id(UUID.randomUUID().toString())
                .code(mainCourse.getCode())
                .name(mainCourse.getName())
                .credit(mainCourse.getCredit())
                .semester(course.getSemester())
                .instructor(course.getInstructor())
                .department(mainCourse.getDepartment())
                .students(course.getStudents())
                .build();

        List<Integer> students = saving.getStudents();

        for(Integer i : students){
            if(!studentRepository.existsByNumber(i)){
                students.remove(i);
                continue;
            }
            Student student = studentRepository.findByNumber(i);
            List<String> enrolledCourses = student.getEnrolledCourses();
            enrolledCourses.add(saving.getCode());
            student.setEnrolledCourses(enrolledCourses);
            studentRepository.save(student);
        }

        saving.setStudents(students);

        Department department = departmentRepository.findByName(course.getDepartment());
        List<String> activeCourses = department.getActiveCourses();
        activeCourses.add(course.getCode());
        department.setActiveCourses(activeCourses);
        departmentRepository.save(department);

        return courseRepository.save(saving);
    }

    public Course update(String code, Integer instructor) {
        if (!courseRepository.existsByCode(code)) {
            throw new IllegalStateException("Course with code " + code + " does not exist");
        }
        Course course = courseRepository.findByCode(code);

        if (instructor != null && instructor > 0 && !instructor.equals(course.getInstructor())) {
            if (!instructorRepository.existsByIdNumber(instructor)) {
                throw new IllegalStateException("Instructor with id number " + instructor + " does not exist.");
            }
            course.setInstructor(instructor);
        }


        return courseRepository.save(course);

    }

    public String delete(String code) {
        if (!courseRepository.existsByCode(code)) {
            return "Course with code " + code + " not exists.";
        }
        Course course = courseRepository.findByCode(code);
        List<Integer> students = course.getStudents();

        for(Integer i : students){
            Student student = studentRepository.findByNumber(i);
            List<String> enrolledCourses = student.getEnrolledCourses();
            enrolledCourses.remove(course.getCode());
            student.setEnrolledCourses(enrolledCourses);
            studentRepository.save(student);
        }

        Department department = departmentRepository.findByName(course.getDepartment());
        List<String> activeCourses = department.getActiveCourses();
        activeCourses.remove(course.getCode());
        department.setActiveCourses(activeCourses);
        departmentRepository.save(department);

        Instructor instructor = instructorRepository.findByIdNumber(course.getInstructor());
        List<String> courses = instructor.getCourses();
        courses.remove(course.getCode());
        instructor.setCourses(courses);
        instructorRepository.save(instructor);


        courseRepository.deleteByCode(code);
        return "Course with code " + code + " deleted successfully.";
    }

    public List<Student> getStudents(String code) {
        Course course = courseRepository.findByCode(code);
        List<Student> students = new ArrayList<>();
        for (Integer i : course.getStudents()) {
            students.add(studentRepository.findByNumber(i));
        }
        return students;
    }

    public List<Student> getStudentGPAGreaterThan(String code, float gpa) {
        Course course = courseRepository.findByCode(code);
        List<Student> students = new ArrayList<>();
        for (Student st : getStudents(course.getCode())) {
            if (st.getGpa() >= gpa) {
                students.add(st);
            }
        }
        return students;
    }
    @Transactional
    public String addStudent(String courseCode, Integer studentNumber) {
        Student student = studentRepository.findByNumber(studentNumber);
        Course course = courseRepository.findByCode(courseCode);

        if(student != null && course != null){
            List<String> studentCourses = student.getEnrolledCourses();
            boolean flag = !studentCourses.contains(courseCode);

            if(flag){

                List<Integer> courseStudents = course.getStudents();
                courseStudents.add(studentNumber);
                course.setStudents(courseStudents);
                courseRepository.save(course);

                Note note = Note.builder()
                        .id(UUID.randomUUID().toString())
                        .studentNumber(studentNumber)
                        .courseCode(courseCode)
                        .letterNote("FF")
                        .courseNote(0F)
                        .build();

                studentCourses.add(courseCode);
                student.setEnrolledCourses(studentCourses);
                studentRepository.save(student);
                noteRepository.save(note);
                return "Student successfully added to course, also vice-versa.";
            }
            return "This Course already taken by whose number is " + studentNumber;
        }
        return "Student with number " + studentNumber + " or course " + courseCode
                + " or both are not exist. Process is failed";
    }
    @Transactional
    public String removeStudent(Integer studentNumber, String courseCode){

        Student student = studentRepository.findByNumber(studentNumber);
        Course course = courseRepository.findByCode(courseCode);

        if (student != null && course != null){
            List<String> courses = student.getEnrolledCourses();
            List<Integer> students = course.getStudents();

            courses.remove(courseCode);
            students.remove(studentNumber);

            course.setStudents(students);
            student.setEnrolledCourses(courses);

            List<Note> notes = noteRepository.findAllByStudentNumber(studentNumber);
            String id = "";
            for(Note note : notes){
                if(note.getCourseCode().equals(courseCode)){
                    id = note.getId();
                    break;
                }
            }

            noteRepository.deleteById(id);
            studentRepository.save(student);
            courseRepository.save(course);
        }


        return "Student with id number " + studentNumber + " successfully added to "
                + courseCode + " if both are exists.";
    }


}
