package com.example.university.services;

import com.example.university.models.*;
import com.example.university.repositories.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class DepartmentService {
    private final DepartmentRepository departmentRepository;
    private final InstructorRepository instructorRepository;
    private final StudentRepository studentRepository;
    private final GraduatedStudentRepository graduatedStudentRepository;
    private final OfficerRepository officerRepository;
    private final CourseRepository courseRepository;
    private final AllCoursesRepository allCoursesRepository;
    private final FacultyRepository facultyRepository;

    ///TODO: Listlere get yazmalisin
    ///TODO: graduatedStudent'la ilgili sorunlara göz at

    public List<Department> findAll() {
        return departmentRepository.findAll();
    }

    public Department findByName(String name) {
        return findByName(name);
    }

    public Department save(Department department) {
        Department saving = Department.builder()
                .id(UUID.randomUUID().toString())
                .name(department.getName())
                .facultyName(department.getFacultyName())
                .headOf(department.getHeadOf())
                .viceHeadOf(department.getViceHeadOf())
                .instructors(department.getInstructors())
                .students(department.getStudents())
                .graduatedStudent(department.getGraduatedStudent())
                .officers(department.getOfficers())
                .courses(department.getCourses())
                .activeCourses(department.getActiveCourses())
                .build();


        Faculty faculty = facultyRepository.findByName(department.getFacultyName());
        List<String> facultyDepartments = faculty.getDepartments();
        facultyDepartments.add(department.getName());
        faculty.setDepartments(facultyDepartments);
        facultyRepository.save(faculty);

        List<Integer> instructors = department.getInstructors();
        for (Integer i : instructors) {
            Instructor instructor = instructorRepository.findByIdNumber(i);
            instructor.setDepartment(department.getName());
            instructorRepository.save(instructor);
        }

        List<Integer> students = department.getStudents();
        for (Integer i : students) {
            Student student = studentRepository.findByNumber(i);
            student.setDepartment(department.getName());
            studentRepository.save(student);
        }

        List<Integer> officers = department.getOfficers();
        for (Integer i : officers) {
            Officer officer = officerRepository.findByIdNumber(i);
            officer.setDepartment(department.getName());
            officerRepository.save(officer);
        }

        List<AllCourses> allCourses = department.getCourses();
        for (AllCourses course : allCourses) {
            AllCourses updateCourse = allCoursesRepository.findByCode(course.getCode());
            updateCourse.setDepartment(department.getName());
            allCoursesRepository.save(updateCourse);
        }

        List<String> activeCourses = department.getActiveCourses();
        for (String s : activeCourses) {
            Course course = courseRepository.findByCode(s);
            course.setDepartment(department.getName());
            courseRepository.save(course);
        }


        return departmentRepository.save(saving);
    }

    @Transactional
    public Department update(String name, Integer head, Integer viceHead) {
        if (!departmentRepository.existsByName(name)) {
            throw new IllegalStateException("Department name "
                    + name + " not found");
        }

        Department department = departmentRepository.findByName(name);

        if (head != null && head > 0 && !head.equals(department.getHeadOf())) {
            if (!instructorRepository.existsByIdNumber(head)) {
                throw new IllegalStateException("Instructor with id " + head + " is not exist");
            }
            department.setHeadOf(head);
        }
        if (viceHead != null && viceHead > 0 && !viceHead.equals(department.getViceHeadOf())) {
            if (!instructorRepository.existsByIdNumber(head)) {
                throw new IllegalStateException("Instructor with id " + head + " is not exist");
            }
            department.setViceHeadOf(viceHead);
        }


        return departmentRepository.save(department);
    }

    public String delete(String name) {
        if (!departmentRepository.existsByName(name)) {
            throw new IllegalStateException("Instructor with id " + name + " is not exist");
        }

        Department department = departmentRepository.findByName(name);

        Faculty faculty = facultyRepository.findByName(department.getFacultyName());
        List<String> facultyDepartments = faculty.getDepartments();
        facultyDepartments.remove(department.getName());
        faculty.setDepartments(facultyDepartments);
        facultyRepository.save(faculty);

        List<Integer> instructors = department.getInstructors();
        for (Integer i : instructors) {
            Instructor instructor = instructorRepository.findByIdNumber(i);
            instructor.setDepartment("NONE");
            instructorRepository.save(instructor);
        }

        List<Integer> students = department.getStudents();
        for (Integer i : students) {
            Student student = studentRepository.findByNumber(i);
            student.setDepartment("NONE");
            studentRepository.save(student);
        }

        List<Integer> officers = department.getOfficers();
        for (Integer i : officers) {
            Officer officer = officerRepository.findByIdNumber(i);
            officer.setDepartment("NONE");
            officerRepository.save(officer);
        }

        List<AllCourses> allCourses = department.getCourses();
        for (AllCourses course : allCourses) {
            AllCourses updateCourse = allCoursesRepository.findByCode(course.getCode());
            updateCourse.setDepartment("NONE");
            allCoursesRepository.save(updateCourse);
        }

        List<String> activeCourses = department.getActiveCourses();
        for (String s : activeCourses) {
            Course course = courseRepository.findByCode(s);
            course.setDepartment("NONE");
            courseRepository.save(course);
        }

        departmentRepository.deleteByName(name);
        return "Department with name " + name + " is deleted successfully";
    }

    public String addInstructor(String departmentName, Integer instructorIDNumber) {
        Department department = departmentRepository.findByName(departmentName);
        Instructor instructor = instructorRepository.findByIdNumber(instructorIDNumber);

        if (instructor != null && department != null) {
            List<Integer> instructors = department.getInstructors();

            if (!instructors.contains(instructorIDNumber)) {
                instructor.setDepartment(departmentName);
                instructorRepository.save(instructor);

                instructors.add(instructorIDNumber);
                department.setInstructors(instructors);
                departmentRepository.save(department);
                return "Instructor with id " + instructorIDNumber + " successfully added to " + departmentName;
            }
            return "Instructor with id " + instructorIDNumber + " is already in " + departmentName;
        }
        return "Department with name " + departmentName + " or instructor with id number " + instructorIDNumber
                + " or both are not exist. Process is failed";
    }

    public String addStudent(String departmentName, Integer studentNumber) {
        Department department = departmentRepository.findByName(departmentName);
        Student student = studentRepository.findByNumber(studentNumber);

        if (student != null && department != null) {
            List<Integer> students = department.getStudents();

            if (!students.contains(studentNumber)) {
                student.setDepartment(departmentName);
                studentRepository.save(student);

                students.add(studentNumber);
                department.setStudents(students);
                departmentRepository.save(department);
                return "Student with number " + studentNumber + " successfully added to " + departmentName;
            }
            return "Student with number " + studentNumber + " is already in " + departmentName;
        }
        return "Department with name " + departmentName + " or student with number " + studentNumber
                + " or both are not exist. Process is failed";
    }

    public String addGraduatedStudent(String departmentName, Integer studentNumber) {
        Department department = departmentRepository.findByName(departmentName);
        GraduatedStudent graduatedStudent = graduatedStudentRepository.findByNumber(studentNumber);

        if (graduatedStudent != null && department != null) {
            List<Integer> students = department.getGraduatedStudent();

            if (!students.contains(studentNumber)) {
                graduatedStudent.setDepartment(departmentName);
                graduatedStudentRepository.save(graduatedStudent);

                students.add(studentNumber);
                department.setStudents(students);
                departmentRepository.save(department);
                return "Graduated student with number " + studentNumber + " successfully added to " + departmentName;
            }
            return "Graduated student with number " + studentNumber + " is already in " + departmentName;
        }
        return "Department with name " + departmentName + " or graduated student with number " + studentNumber
                + " or both are not exist. Process is failed";
    }

    public String addOfficer(String departmentName, Integer officerNumber) {
        Department department = departmentRepository.findByName(departmentName);
        Officer officer = officerRepository.findByIdNumber(officerNumber);

        if (officer != null && department != null) {
            List<Integer> officers = department.getOfficers();

            if (!officers.contains(officerNumber)) {
                officer.setDepartment(departmentName);
                officerRepository.save(officer);

                officers.add(officerNumber);
                department.setInstructors(officers);
                departmentRepository.save(department);
                return "Officer with id " + officerNumber + " successfully added to " + departmentName;
            }
            return "Officer with id " + officerNumber + " is already in " + departmentName;
        }
        return "Department with name " + departmentName + " or officer with id number " + officerNumber
                + " or both are not exist. Process is failed";
    }

    public String addCourse(String departmentName, String courseCode) {
        Department department = departmentRepository.findByName(departmentName);
        AllCourses course = allCoursesRepository.findByCode(courseCode);

        if (course != null && department != null) {
            List<AllCourses> courses = department.getCourses();


            if (!courses.contains(course)) {
                course.setDepartment(departmentName);
                allCoursesRepository.save(course);

                courses.add(course);
                department.setCourses(courses);
                departmentRepository.save(department);
                return "Course with code " + courseCode + " successfully added to " + departmentName;
            }
            return "Course with code " + courseCode + " is already in " + departmentName;
        }
        return "Department with name " + departmentName + " or course with id code " + courseCode
                + " or both are not exist. Process is failed";
    }

    public String addActiveCourse(String departmentName, String courseCode) {
        Department department = departmentRepository.findByName(departmentName);
        Course course = courseRepository.findByCode(courseCode);

        if (course != null && department != null) {
            List<String> activeCourses = department.getActiveCourses();

            if (!activeCourses.contains(courseCode)) {
                course.setDepartment(departmentName);
                courseRepository.save(course);

                activeCourses.add(courseCode);
                department.setActiveCourses(activeCourses);
                departmentRepository.save(department);
                return "Active course with code " + courseCode + " successfully added to " + departmentName;
            }
            return "Course with code " + courseCode + " is already active in " + departmentName;
        }
        return "Department with name " + departmentName + " or course with id code " + courseCode
                + " or both are not exist. Process is failed";
    }

    public String removeInstructor(String departmentName, Integer instructorNumber) {
        Department department = departmentRepository.findByName(departmentName);
        Instructor instructor = instructorRepository.findByIdNumber(instructorNumber);

        if (department != null && instructor != null) {
            List<Integer> instructors = department.getInstructors();
            if (instructors.contains(instructorNumber)) {
                instructors.remove(instructorNumber);
                department.setInstructors(instructors);
                departmentRepository.save(department);

                instructor.setDepartment("NONE");
                instructorRepository.save(instructor);

                return "Instructor with ID Number " + instructorNumber
                        + " is successfully deleted from department of " + departmentName;
            }
            return "Instructor with ID Number " + instructorNumber + "'s department is not " + departmentName;
        }
        return "Department with name " + departmentName + " or instructor with id number " + instructorNumber
                + " or both are not exist. Process is failed";
    }

    public String removeStudent(String departmentName, Integer studentNumber) {
        Department department = departmentRepository.findByName(departmentName);
        Student student = studentRepository.findByNumber(studentNumber);

        if (department != null && student != null) {
            List<Integer> students = department.getStudents();
            if (students.contains(studentNumber)) {
                students.remove(studentNumber);
                department.setStudents(students);
                departmentRepository.save(department);

                student.setDepartment("NONE");
                studentRepository.save(student);


                return "Student with ID Number " + studentNumber
                        + " is successfully deleted from department of " + departmentName;
            }
            return "Student with ID Number " + studentNumber + "'s department is not " + departmentName;
        }
        return "Department with name " + departmentName + " or student with id number " + studentNumber
                + " or both are not exist. Process is failed";
    }

    public String removeGraduatedStudent(String departmentName, Integer studentNumber) {
        Department department = departmentRepository.findByName(departmentName);
        GraduatedStudent student = graduatedStudentRepository.findByNumber(studentNumber);

        if (department != null && student != null) {
            List<Integer> students = department.getGraduatedStudent();
            if (students.contains(studentNumber)) {
                students.remove(studentNumber);
                department.setGraduatedStudent(students);
                departmentRepository.save(department);

                student.setDepartment("NONE");
                graduatedStudentRepository.save(student);

                return "Student with ID Number " + studentNumber
                        + " is successfully deleted from department of " + departmentName;
            }
            return "Student with ID Number " + studentNumber + "'s department is not " + departmentName;
        }
        return "Department with name " + departmentName + " or student with id number " + studentNumber
                + " or both are not exist. Process is failed";
    }

    public String removeOfficer(String departmentName, Integer officerNumber) {
        Department department = departmentRepository.findByName(departmentName);
        Officer officer = officerRepository.findByIdNumber(officerNumber);

        if (department != null && officer != null) {
            List<Integer> officers = department.getOfficers();
            if (officers.contains(officerNumber)) {
                officers.remove(officerNumber);
                department.setOfficers(officers);
                departmentRepository.save(department);

                officer.setDepartment("NONE");
                officerRepository.save(officer);

                return "Officer with ID Number " + officerNumber
                        + " is successfully deleted from department of " + departmentName;
            }
            return "Officer with ID Number " + officerNumber + "'s department is not " + departmentName;
        }
        return "Department with name " + departmentName + " or officer with id number " + officerNumber
                + " or both are not exist. Process is failed";
    }

    public String removeCourse(String departmentName, String courseCode) {
        Department department = departmentRepository.findByName(departmentName);
        AllCourses course = allCoursesRepository.findByCode(courseCode);

        if (department != null && course != null) {
            List<AllCourses> courses = department.getCourses();
            if (courses.contains(course)) {
                courses.remove(course);
                department.setCourses(courses);
                departmentRepository.save(department);

                course.setDepartment("NONE");
                allCoursesRepository.save(course);

                return "Course with code " + courseCode
                        + " is successfully deleted from department of " + departmentName;
            }
            return "Course with code " + courseCode + "'s department is not " + departmentName;
        }
        return "Department with name " + departmentName + " or course with code " + courseCode
                + " or both are not exist. Process is failed";
    }

    public String removeActiveCourse(String departmentName, String courseCode) {
        Department department = departmentRepository.findByName(departmentName);
        Course course = courseRepository.findByCode(courseCode);

        if (department != null && course != null) {
            List<String> courses = department.getActiveCourses();
            if (courses.contains(courseCode)) {
                courses.remove(courseCode);
                department.setActiveCourses(courses);
                departmentRepository.save(department);

                course.setDepartment("NONE");
                courseRepository.save(course);

                return "Active course with code " + courseCode
                        + " is successfully deleted from department of " + departmentName;
            }
            return "Active course with code " + courseCode + "'s department is not " + departmentName;
        }
        return "Department with name " + departmentName + " or active course with code " + courseCode
                + " or both are not exist. Process is failed";
    }

}
