package com.example.university.services;

import com.example.university.models.*;
import com.example.university.repositories.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class FacultyService {
    private final AdministrationRepository administrationRepository;
    private final DepartmentRepository departmentRepository;
    private final FacultyRepository facultyRepository;
    private final InstructorRepository instructorRepository;
    private final OfficerRepository officerRepository;
    private final StudentRepository studentRepository;

    public List<Faculty> findAll() {
        return facultyRepository.findAll();
    }

    public Faculty findByName(String name) {
        return facultyRepository.findByName(name);
    }

    public Faculty save(Faculty faculty) {
        Faculty saving = Faculty.builder()
                .id(UUID.randomUUID().toString())
                .name(faculty.getName())
                .dean(faculty.getDean())
                .viceDean(faculty.getViceDean())
                .departments(faculty.getDepartments())
                .instructors(faculty.getInstructors())
                .officers(faculty.getOfficers())
                .students(faculty.getStudents())
                .build();

        List<String> departments = faculty.getDepartments();
        for (String s : departments) {
            Department department = departmentRepository.findByName(s);
            department.setFacultyName(faculty.getName());
            departmentRepository.save(department);
        }

        List<Integer> officers = faculty.getOfficers();
        for (Integer i : officers) {
            Officer officer = officerRepository.findByIdNumber(i);
            officer.setDepartment(faculty.getName());
            officerRepository.save(officer);
        }


        return facultyRepository.save(saving);
    }

    @Transactional
    public Faculty update(String name, Integer dean, Integer viceDean) {
        if (!facultyRepository.existsByName(name)) {
            throw new IllegalStateException("Faculty with name " + name + " does not exist.");
        }
        Faculty faculty = facultyRepository.findByName(name);

        if (dean != null && dean > 0 && !dean.equals(faculty.getDean())) {
            if (!instructorRepository.existsByIdNumber(dean)) {
                throw new IllegalStateException("Instructor with id number " + dean + " does not exist.");
            }
            faculty.setDean(dean);
        }
        if (viceDean != null && viceDean > 0 && !viceDean.equals(faculty.getViceDean())) {
            if (!instructorRepository.existsByIdNumber(viceDean)) {
                throw new IllegalStateException("Instructor with id number " + viceDean + " does not exist.");
            }
            faculty.setViceDean(dean);
        }
        return facultyRepository.save(faculty);
    }

    @Transactional
    public Faculty updateName(String id, String name) {
        if (!facultyRepository.existsById(id)) {
            throw new IllegalStateException("Faculty with id " + id + " does not exist.");
        }
        Faculty faculty = facultyRepository.findById(id).orElseThrow();

        if (name != null && name.length() > 0 && !name.equals(faculty.getName())) {
            Administration administration = administrationRepository.findByName("Rectorate");
            List<String> faculties = administration.getFaculties();
            faculties.remove(faculty.getName());

            faculty.setName(name);
            faculties.add(name);
            administration.setFaculties(faculties);

            administrationRepository.save(administration);

            List<String> departments = faculty.getDepartments();
            for (String s : departments) {
                Department department = departmentRepository.findByName(s);
                department.setFacultyName(name);
                departmentRepository.save(department);
            }

            List<Integer> officers = faculty.getOfficers();
            for (Integer i : officers) {
                Officer officer = officerRepository.findByIdNumber(i);
                officer.setDepartment(name);
                officerRepository.save(officer);
            }

        }
        return facultyRepository.save(faculty);
    }

    public String delete(String name) {
        if (!facultyRepository.existsByName(name)) {
            return "Faculty with name " + name + " does not exist";
        }
        Faculty faculty = facultyRepository.findByName(name);

        Administration administration = administrationRepository.findByName("Rectorate");
        List<String> faculties = administration.getFaculties();
        faculties.remove(name);
        administration.setFaculties(faculties);
        administrationRepository.save(administration);

        List<String> departments = faculty.getDepartments();
        for (String s : departments) {
            Department department = departmentRepository.findByName(s);
            department.setFacultyName("NONE");
            departmentRepository.save(department);
        }

        List<Integer> officers = faculty.getOfficers();
        for (Integer i : officers) {
            Officer officer = officerRepository.findByIdNumber(i);
            officer.setDepartment("NONE");
            officerRepository.save(officer);
        }


        facultyRepository.deleteByName(name);

        return "Faculty with name " + name + " is successfully deleted.";
    }

    public List<Department> getDepartments(String name) {
        Faculty faculty = facultyRepository.findByName(name);
        List<Department> departments = new ArrayList<>();
        for (String s : faculty.getDepartments()) {
            departments.add(departmentRepository.findByName(s));
        }
        return departments;
    }

    public List<Instructor> getInstructors(String name) {
        Faculty faculty = facultyRepository.findByName(name);
        List<Instructor> instructors = new ArrayList<>();
        for (Integer i : faculty.getInstructors()) {
            instructors.add(instructorRepository.findByIdNumber(i));
        }
        return instructors;
    }

    public List<Officer> getOfficers(String name) {
        Faculty faculty = facultyRepository.findByName(name);
        List<Officer> officers = new ArrayList<>();
        for (Integer i : faculty.getOfficers()) {
            officers.add(officerRepository.findByIdNumber(i));
        }
        return officers;
    }

    public List<Student> getStudents(String name) {
        Faculty faculty = facultyRepository.findByName(name);
        List<Student> students = new ArrayList<>();
        for (Integer i : faculty.getStudents()) {
            students.add(studentRepository.findByNumber(i));
        }
        return students;
    }

    @Transactional
    public String addDepartment(String facultyName, String departmentName) {
        Faculty faculty = facultyRepository.findByName(facultyName);
        Department department = departmentRepository.findByName(departmentName);

        if (faculty != null && department != null) {
            List<String> departments = faculty.getDepartments();
            boolean flag = !departments.contains(departmentName);

            if (flag) {
                department.setFacultyName(facultyName);
                departmentRepository.save(department);

                departments.add(departmentName);
                faculty.setDepartments(departments);
                facultyRepository.save(faculty);
                return "Department is successfully added to faculty";
            }
            return "This department is already in that faculty";
        }
        return "Department with name " + departmentName + " or  faculty " + facultyName
                + " or both are not exist. Process is failed.";
    }

    @Transactional
    public String addInstructor(String facultyName, Integer instructorID) {
        Faculty faculty = facultyRepository.findByName(facultyName);
        Instructor instructor = instructorRepository.findByIdNumber(instructorID);

        if (faculty != null && instructor != null) {
            List<Integer> instructors = faculty.getInstructors();
            boolean flag = !instructors.contains(instructorID);

            if (flag) {
                instructors.add(instructorID);
                faculty.setInstructors(instructors);
                facultyRepository.save(faculty);
                return "Instructor successfully added to faculty";
            }
            return "This instructor is already in that faculty";
        }
        return "Instructor with ID number " + instructorID + " or  faculty " + facultyName
                + " or both are not exist. Process is failed.";
    }

    @Transactional
    public String addOfficer(String facultyName, Integer officerID) {
        Faculty faculty = facultyRepository.findByName(facultyName);
        Officer officer = officerRepository.findByIdNumber(officerID);

        if (faculty != null && officer != null) {
            List<Integer> officers = faculty.getOfficers();
            boolean flag = !officers.contains(officerID);

            if (flag) {
                officers.add(officerID);
                faculty.setOfficers(officers);
                facultyRepository.save(faculty);
                return "Officer successfully added to faculty";
            }
            return "This officer is already in that faculty";
        }
        return "Officer with ID number " + officerID + " or  faculty " + facultyName
                + " or both are not exist. Process is failed.";
    }

    @Transactional
    public String addStudent(String facultyName, Integer studentNumber) {
        Faculty faculty = facultyRepository.findByName(facultyName);
        Student student = studentRepository.findByNumber(studentNumber);

        if (faculty != null && student != null) {
            List<Integer> students = faculty.getStudents();
            boolean flag = !students.contains(studentNumber);

            if (flag) {
                students.add(studentNumber);
                faculty.setOfficers(students);
                facultyRepository.save(faculty);
                return "Student successfully added to faculty";
            }
            return "This student is already in that faculty";
        }
        return "Student with number " + studentNumber + " or  faculty " + facultyName
                + " or both are not exist. Process is failed.";
    }

    @Transactional
    public String removeDepartment(String facultyName, String departmentName) {

        Faculty faculty = facultyRepository.findByName(facultyName);
        Department department = departmentRepository.findByName(departmentName);

        if (faculty != null && department != null) {
            List<String> departments = faculty.getDepartments();

            departments.remove(departmentName);
            department.setFacultyName("NONE");

            faculty.setDepartments(departments);

            facultyRepository.save(faculty);
            departmentRepository.save(department);
        }

        return "Department " + departmentName + " is removed from faculty "
                + facultyName + " if both are exists.";
    }

    @Transactional
    public String removeInstructor(String facultyName, Integer instructorID) {

        Faculty faculty = facultyRepository.findByName(facultyName);

        if (faculty != null) {
            List<Integer> instructors = faculty.getInstructors();

            instructors.remove(instructorID);

            faculty.setInstructors(instructors);

            facultyRepository.save(faculty);
        }

        return "Instructor with ID number " + instructorID + " is removed from faculty "
                + facultyName + " if both are exists.";
    }

    @Transactional
    public String removeOfficer(String facultyName, Integer officerID) {

        Faculty faculty = facultyRepository.findByName(facultyName);

        if (faculty != null) {
            List<Integer> officers = faculty.getOfficers();

            officers.remove(officerID);

            faculty.setOfficers(officers);

            facultyRepository.save(faculty);
        }

        return "Officer with ID number " + officerID + " is removed from faculty "
                + facultyName + " if both are exists.";
    }

    @Transactional
    public String removeStudent(String facultyName, Integer studentNumber) {

        Faculty faculty = facultyRepository.findByName(facultyName);

        if (faculty != null) {
            List<Integer> students = faculty.getStudents();

            students.remove(studentNumber);

            faculty.setStudents(students);

            facultyRepository.save(faculty);
        }

        return "Student with ID number " + studentNumber + " is removed from faculty "
                + facultyName + " if both are exists.";
    }

}
