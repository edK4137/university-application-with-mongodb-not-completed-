package com.example.university.services;

import com.example.university.models.CompletedCourse;
import com.example.university.models.Department;
import com.example.university.models.GraduatedStudent;
import com.example.university.repositories.DepartmentRepository;
import com.example.university.repositories.GraduatedStudentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor

public class GraduatedStudentService {
    private final GraduatedStudentRepository graduatedStudentRepository;
    private final DepartmentRepository departmentRepository;

    public List<GraduatedStudent> findAll() {
        return graduatedStudentRepository.findAll();
    }

    public GraduatedStudent findByNumber(Integer number) {
        return graduatedStudentRepository.findByNumber(number);
    }

    public GraduatedStudent save(GraduatedStudent student) {
        GraduatedStudent saving = GraduatedStudent.builder()
                .id(UUID.randomUUID().toString())
                .number(student.getNumber())
                .name(student.getName())
                .department(student.getDepartment())
                .gpa(student.getGpa())
                .completedCourses(student.getCompletedCourses())
                .build();

        Department department = departmentRepository.findByName(student.getDepartment());
        List<Integer> graduatedStudent = department.getGraduatedStudent();
        graduatedStudent.add(student.getNumber());
        department.setGraduatedStudent(graduatedStudent);
        departmentRepository.save(department);
        return graduatedStudentRepository.save(saving);
    }

    public List<CompletedCourse> getCourses(Integer number) {
        GraduatedStudent student = graduatedStudentRepository.findByNumber(number);
        return student.getCompletedCourses();
    }
}
