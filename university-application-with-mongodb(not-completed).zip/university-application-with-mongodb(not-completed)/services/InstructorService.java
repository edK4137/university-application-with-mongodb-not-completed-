package com.example.university.services;

import com.example.university.models.*;
import com.example.university.repositories.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class InstructorService {
    private final InstructorRepository instructorRepository;
    private final DepartmentRepository departmentRepository;
    private final CourseRepository courseRepository;
    private final AllCoursesRepository allCoursesRepository;
    private final AdministrationRepository administrationRepository;
    private final FacultyRepository facultyRepository;

    public List<Instructor> findAll() {
        return instructorRepository.findAll();
    }

    public Instructor findByIdNumber(Integer number) {
        return instructorRepository.findByIdNumber(number);
    }

    public Instructor save(Instructor instructor) {
        Instructor saving = Instructor.builder()
                .id(UUID.randomUUID().toString())
                .idNumber(instructor.getIdNumber())
                .name(instructor.getName())
                .department(instructor.getDepartment())
                .email(instructor.getEmail())
                .courses(instructor.getCourses())
                .coursesCanTeach(instructor.getCoursesCanTeach())
                .build();

        Department department = departmentRepository.findByName(instructor.getDepartment());
        List<Integer> departmentInstructors = department.getInstructors();
        departmentInstructors.add(instructor.getIdNumber());
        department.setInstructors(departmentInstructors);
        departmentRepository.save(department);

        List<String> courses = instructor.getCourses();
        for (String s : courses) {
            Course course = courseRepository.findByCode(s);
            course.setInstructor(instructor.getIdNumber());
            courseRepository.save(course);
        }

        Faculty faculty = facultyRepository.findByName(department.getFacultyName());
        List<Integer> facultyInstructors = faculty.getInstructors();
        facultyInstructors.add(instructor.getIdNumber());
        facultyRepository.save(faculty);

        return instructorRepository.save(saving);
    }

    @Transactional
    public Instructor update(Integer idNumber, String name, String department, String email) {
        if (!instructorRepository.existsByIdNumber(idNumber)) {
            throw new IllegalStateException("Instructor with ID number " + idNumber + " does not exist.");
        }
        Instructor instructor = instructorRepository.findByIdNumber(idNumber);

        if (name != null && name.length() > 0 && !name.equals(instructor.getName())) {
            instructor.setName(name);
        }
        if (department != null && department.length() > 0 && !department.equals(instructor.getDepartment())) {
            if (!departmentRepository.existsByName(department)) {
                throw new IllegalStateException("Department does not exist.");
            }
            instructor.setDepartment(department);
        }
        if (email != null && email.length() > 0 && !email.equals(instructor.getEmail())) {
            instructor.setEmail(email);
        }
        return instructorRepository.save(instructor);
    }

    @Transactional
    public Instructor updateIDNumber(String id, Integer number) {
        if (!instructorRepository.existsById(id)) {
            throw new IllegalStateException("Instructor with ID " + id + " does not exist.");
        }
        Instructor instructor = instructorRepository.findById(id).orElseThrow();

        if (number != null && number > 0 && !number.equals(instructor.getIdNumber())) {
            if (instructorRepository.existsByIdNumber(number)) {
                throw new IllegalStateException("This number is already taken.");
            }

            Administration admin = administrationRepository.findByName("Rectorate");
            if (admin.getRector().equals(instructor.getIdNumber())) {
                admin.setRector(number);
            }
            if (admin.getViceRector().equals(instructor.getIdNumber())) {
                admin.setViceRector(number);
            }

            List<String> courses = instructor.getCourses();
            for (String s : courses) {
                Course course = courseRepository.findByCode(s);
                course.setInstructor(number);
                courseRepository.save(course);
            }

            Department department = departmentRepository.findByName(instructor.getDepartment());
            List<Integer> instructors = department.getInstructors();
            instructors.remove(instructor.getIdNumber());
            instructors.add(number);
            department.setInstructors(instructors);

            Faculty faculty = facultyRepository.findByName(department.getFacultyName());
            List<Integer> instructors2 = faculty.getInstructors();
            instructors2.remove(instructor.getIdNumber());
            instructors2.add(number);
            faculty.setInstructors(instructors2);


            instructor.setIdNumber(number);

            administrationRepository.save(admin);
            departmentRepository.save(department);
            facultyRepository.save(faculty);
        }
        return instructorRepository.save(instructor);
    }

    public String delete(Integer number) {
        if (!instructorRepository.existsByIdNumber(number)) {
            return "Instructor with ID " + number + " does not exist";
        }

        Instructor instructor = instructorRepository.findByIdNumber(number);

        Administration admin = administrationRepository.findByName("Rectorate");
        if (admin.getRector().equals(number)) {
            admin.setRector(-1);
        }
        if (admin.getViceRector().equals(number)) {
            admin.setViceRector(-1);
        }

        List<String> courses = instructor.getCourses();
        for (String s : courses) {
            Course course = courseRepository.findByCode(s);
            course.setInstructor(-1);
            courseRepository.save(course);
        }

        Department department = departmentRepository.findByName(instructor.getDepartment());
        List<Integer> instructors = department.getInstructors();
        instructors.remove(number);
        department.setInstructors(instructors);

        Faculty faculty = facultyRepository.findByName(department.getFacultyName());
        List<Integer> instructors2 = faculty.getInstructors();
        instructors2.remove(number);
        faculty.setInstructors(instructors2);


        administrationRepository.save(admin);
        departmentRepository.save(department);
        facultyRepository.save(faculty);

        instructorRepository.deleteByIdNumber(number);
        return "Instructor with ID number " + number + " is successfully deleted";
    }

    public List<Course> getCourses(Integer number) {
        Instructor instructor = instructorRepository.findByIdNumber(number);
        List<Course> courses = new ArrayList<>();
        for (String s : instructor.getCourses()) {
            courses.add(courseRepository.findByCode(s));
        }
        return courses;
    }

    public List<AllCourses> getAllCourses(Integer number) {
        Instructor instructor = instructorRepository.findByIdNumber(number);
        List<AllCourses> courses = new ArrayList<>();
        for (String s : instructor.getCoursesCanTeach()) {
            courses.add(allCoursesRepository.findByCode(s));
        }
        return courses;
    }

    @Transactional
    public String addCourse(Integer instructorID, String courseCode) {
        Instructor instructor = instructorRepository.findByIdNumber(instructorID);
        Course course = courseRepository.findByCode(courseCode);

        if (instructor != null && course != null) {
            List<String> courses = instructor.getCourses();
            boolean flag = !courses.contains(courseCode);
            if (flag) {
                course.setInstructor(instructorID);
                courseRepository.save(course);

                courses.add(courseCode);
                instructor.setCourses(courses);
                instructorRepository.save(instructor);
                return "Course is successfully added to instructor.";
            }
            return "Course is already registered to instructor.";
        }
        return "Course with code " + courseCode + " or  instructor with ID number " + instructorID
                + " or both are not exist. Process is failed.";
    }

    @Transactional
    public String addCourseCanTeach(Integer instructorID, String courseCode) {
        Instructor instructor = instructorRepository.findByIdNumber(instructorID);
        AllCourses course = allCoursesRepository.findByCode(courseCode);

        if (instructor != null && course != null) {
            List<String> courses = instructor.getCoursesCanTeach();
            boolean flag = !courses.contains(courseCode);

            if (flag) {
                courses.add(courseCode);
                instructor.setCourses(courses);
                instructorRepository.save(instructor);
                return "Course is successfully added to instructor.";
            }
            return "Course is already registered to instructor.";
        }
        return "Course with code " + courseCode + " or  instructor with ID number " + instructorID
                + " or both are not exist. Process is failed.";
    }

    @Transactional
    public String removeCourse(Integer instructorID, String courseCode) {
        Instructor instructor = instructorRepository.findByIdNumber(instructorID);
        Course course = courseRepository.findByCode(courseCode);

        if (instructor != null && course != null) {
            List<String> courses = instructor.getCourses();

            courses.remove(courseCode);
            course.setInstructor(-1);

            instructor.setCourses(courses);
            instructorRepository.save(instructor);
            courseRepository.save(course);
        }

        return "Course with course code " + courseCode + " is removed from instructor with id number "
                + instructorID + " if both are exists.";
    }

    @Transactional
    public String removeCourseCanTeach(Integer instructorID, String courseCode) {
        Instructor instructor = instructorRepository.findByIdNumber(instructorID);
        AllCourses course = allCoursesRepository.findByCode(courseCode);

        if (instructor != null && course != null) {
            List<String> courses = instructor.getCourses();

            courses.remove(courseCode);

            instructor.setCourses(courses);
            instructorRepository.save(instructor);
        }

        return "Course with course code " + courseCode + " is removed from instructor with id number "
                + instructorID + " if both are exists.";
    }
}
