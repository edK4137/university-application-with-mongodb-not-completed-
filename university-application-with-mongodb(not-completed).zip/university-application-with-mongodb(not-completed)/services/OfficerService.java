package com.example.university.services;

import com.example.university.models.Administration;
import com.example.university.models.Department;
import com.example.university.models.Faculty;
import com.example.university.models.Officer;
import com.example.university.repositories.AdministrationRepository;
import com.example.university.repositories.DepartmentRepository;
import com.example.university.repositories.FacultyRepository;
import com.example.university.repositories.OfficerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OfficerService {

    public final OfficerRepository officerRepository;
    public final AdministrationRepository administrationRepository;
    public final DepartmentRepository departmentRepository;
    public final FacultyRepository facultyRepository;

    public List<Officer> findAll() {
        return officerRepository.findAll();
    }

    public Officer findByIdNumber(Integer number) {
        return officerRepository.findByIdNumber(number);
    }

    public Officer save(Officer officer) {
        Officer saving = Officer.builder()
                .id(UUID.randomUUID().toString())
                .idNumber(officer.getIdNumber())
                .name(officer.getName())
                .department(officer.getDepartment())
                .title(officer.getTitle())
                .email(officer.getEmail())
                .build();

        Department department = departmentRepository.findByName(officer.getDepartment());
        Faculty faculty = facultyRepository.findByName(officer.getDepartment());
        if(department != null){
            List<Integer> officers = department.getOfficers();
            officers.add(officer.getIdNumber());
            department.setOfficers(officers);
            departmentRepository.save(department);
        } else if(faculty != null){
            List<Integer> officers = faculty.getOfficers();
            officers.add(officer.getIdNumber());
            faculty.setOfficers(officers);
            facultyRepository.save(faculty);
        } else {
            Administration admin = administrationRepository.findByName("Rectorate");
            List<Integer> officers = admin.getOfficers();
            officers.add(officer.getIdNumber());
            admin.setOfficers(officers);
            administrationRepository.save(admin);
        }

        return officerRepository.save(saving);
    }

    @Transactional
    public Officer update(Integer idNumber, String name, String department, String title, String email) {
        if (!officerRepository.existsByIdNumber(idNumber)) {
            throw new IllegalStateException("Officer with ID Number " + idNumber + " does not exist.");
        }
        Officer officer = officerRepository.findByIdNumber(idNumber);

        if (name != null && name.length() > 0 && !name.equals(officer.getName())) {
            officer.setName(name);
        }

        if (department != null && department.length() > 0 && !department.equals(officer.getDepartment())) {
            if (!departmentRepository.existsByName(department)) {
                throw new IllegalStateException("Department with name " + department + " does not exist.");
            }
            Department officerDepartment = departmentRepository.findByName(department);
            List<Integer> officers = officerDepartment.getOfficers();
            officers.add(idNumber);
            officerDepartment.setOfficers(officers);
            departmentRepository.save(officerDepartment);

            officer.setDepartment(department);
        }

        if (title != null && title.length() > 0 && !title.equals(officer.getTitle())) {
            officer.setTitle(title);
        }

        if (email != null && email.length() > 0 && !email.equals(officer.getEmail())) {
            officer.setEmail(email);
        }

        return officerRepository.save(officer);
    }

    public String delete(Integer number){
        if(!officerRepository.existsByIdNumber(number)){
            return "Officer with ID " + number + " does not exist.";
        }
        Officer officer = officerRepository.findByIdNumber(number);

        Department department = departmentRepository.findByName(officer.getDepartment());
        Faculty faculty = facultyRepository.findByName(officer.getDepartment());
        if(department != null){
            List<Integer> officers = department.getOfficers();
            officers.remove(officer.getIdNumber());
            department.setOfficers(officers);
            departmentRepository.save(department);
        } else if(faculty != null){
            List<Integer> officers = faculty.getOfficers();
            officers.remove(officer.getIdNumber());
            faculty.setOfficers(officers);
            facultyRepository.save(faculty);
        } else {
            Administration admin = administrationRepository.findByName("Rectorate");
            List<Integer> officers = admin.getOfficers();
            officers.remove(officer.getIdNumber());
            admin.setOfficers(officers);
            administrationRepository.save(admin);
        }
        officerRepository.deleteByIdNumber(number);
        return "Officer with ID " + number + " is successfully deleted";

    }

    @Transactional
    public Officer updateIdNumber(String id, Integer idNumber) {
        if (!officerRepository.existsById(id)) {
            throw new IllegalStateException("Officer with id " + id + " does not exist.");
        }
        Officer officer = officerRepository.findById(id).orElseThrow();

        if (idNumber != null && idNumber > 0 && !idNumber.equals(officer.getIdNumber())) {
            Department department = departmentRepository.findByName(officer.getDepartment());
            Faculty faculty = facultyRepository.findByName(officer.getDepartment());
            if(department != null){
                List<Integer> officers = department.getOfficers();
                officers.add(idNumber);
                officers.remove(officer.getIdNumber());
                department.setOfficers(officers);
                departmentRepository.save(department);
            } else if(faculty != null){
                List<Integer> officers = faculty.getOfficers();
                officers.add(idNumber);
                officers.remove(officer.getIdNumber());
                faculty.setOfficers(officers);
                facultyRepository.save(faculty);
            } else {
                Administration admin = administrationRepository.findByName("Rectorate");
                List<Integer> officers = admin.getOfficers();
                officers.add(idNumber);
                officers.remove(officer.getIdNumber());
                admin.setOfficers(officers);
                administrationRepository.save(admin);
            }
            officer.setIdNumber(idNumber);
        }
        return officerRepository.save(officer);
    }
}
