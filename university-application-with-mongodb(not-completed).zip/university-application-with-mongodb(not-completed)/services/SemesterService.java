package com.example.university.services;

import com.example.university.models.*;
import com.example.university.repositories.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class SemesterService {
    private final SemesterRepository semesterRepository;
    private final CourseRepository courseRepository;
    private final DepartmentRepository departmentRepository;
    private final GraduatedStudentRepository graduatedStudentRepository;
    private final StudentRepository studentRepository;
    private final NoteRepository noteRepository;
    private final CompletedCourseRepository completedCourseRepository;

    public List<Semester> findAll(){
        return semesterRepository.findAll();
    }

    public Semester findByName(String name){
        return semesterRepository.findByName(name);
    }

    public Semester save(Semester semester){
        Semester saving = Semester.builder()
                .id(UUID.randomUUID().toString())
                .name(semester.getName())
                .startDate(semester.getStartDate())
                .endTime(semester.getEndTime())
                .isCompleted(semester.isCompleted())
                .build();
        List<CompletedCourse> courses = new ArrayList<>();
        saving.setCourses(courses);

        return saving;
    }

    public String endSemester(String name){
        if(!semesterRepository.existsByName(name)){
            return "Semester with giving name \"" + name + "\" does not exist";
        }
        Semester semester = semesterRepository.findByName(name);
        if(semester.isCompleted()){
            return "This semester is already ended.";
        }
        List<CompletedCourse> completedCourses = semester.getCourses();
        List<Course> courses = courseRepository.findAll();
        for(Course c : courses){
            List<Integer> studentNumbers = c.getStudents();
            for(Integer i : studentNumbers){
                Student student = studentRepository.findByNumber(i);
                Note note = noteRepository.findByStudentNumberAndCourseCode(i, c.getCode());
                CompletedCourse completedCourse = CompletedCourse.builder()
                        .id(UUID.randomUUID().toString())
                        .code(c.getCode())
                        .name(c.getName())
                        .credit(c.getCredit())
                        .studentID(student.getId())
                        .letterNote(note.getLetterNote())
                        .build();
                CompletedCourse saved = completedCourseRepository.save(completedCourse);
                completedCourses.add(saved);

                List<String> studentCourses = student.getEnrolledCourses();
                studentCourses.remove(c.getCode());
                student.setEnrolledCourses(studentCourses);
                studentRepository.save(student);
                studentNumbers.remove(i);
            }
            c.setStudents(studentNumbers);
            courseRepository.save(c);
        }

        List<Integer> graduationStudents = studentUpdate();

        semester.setCompleted(true);
        semester.setCourses(completedCourses);
        courseRepository.deleteAll();
        graduation(graduationStudents);
        semesterRepository.save(semester);
        return "Semester " + name + " is ended successfully.";
    }

    private List<Integer> studentUpdate(){
        List<Integer> graduationStudents = new ArrayList<>();
        List<Student> students = studentRepository.findAll();
        for(Student s : students){
            List<String> empty = new ArrayList<>();
            s.setEnrolledCourses(empty);
            Integer sem = s.getSemester();
            s.setSemester(++sem);
            if(s.getSemester() > 8){
                graduationStudents.add(s.getNumber());
            }
            studentRepository.save(s);
        }
        return graduationStudents;
    }

    private void graduation(List<Integer> graduationStudents){
        for(Integer i : graduationStudents){
            Student student = studentRepository.findByNumber(i);
            List<CompletedCourse> completedCourses = new ArrayList<>();

            for(String id : student.getCompletedCourses()){
                completedCourses.add(completedCourseRepository.findById(id).orElseThrow());
            }

            GraduatedStudent graduatedStudent = GraduatedStudent.builder()
                    .id(student.getId())
                    .number(student.getNumber())
                    .name(student.getName())
                    .department(student.getDepartment())
                    .gpa(student.getGpa())
                    .completedCourses(completedCourses)
                    .build();

            graduatedStudentRepository.save(graduatedStudent);

            Department department = departmentRepository.findByName(student.getDepartment());
            List<Integer> students = department.getStudents();
            students.remove(student.getNumber());
            department.setStudents(students);

            List<Integer> graduatedStudents = department.getGraduatedStudent();
            graduatedStudents.add(graduatedStudent.getNumber());
            department.setGraduatedStudent(graduatedStudents);

            departmentRepository.save(department);
        }
    }
}
