package com.example.university.services;

import com.example.university.models.*;
import com.example.university.repositories.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class StudentService {
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;
    private final CompletedCourseRepository completedCourseRepository;
    private final DepartmentRepository departmentRepository;
    private final FacultyRepository facultyRepository;
    private final NoteRepository noteRepository;

    public List<Student> findAll() {
        return studentRepository.findAll();
    }

    public Student findByNumber(Integer number) {
        return studentRepository.findByNumber(number);
    }

    public Student save(Student student) {
        Student saving = Student.builder()
                .id(UUID.randomUUID().toString())
                .number(student.getNumber())
                .name(student.getName())
                .department(student.getDepartment())
                .email(student.getEmail())
                .gpa(student.getGpa())
                .semester(1)
                .enrolledCourses(student.getEnrolledCourses())
                .completedCourses(student.getCompletedCourses())
                .build();
        return studentRepository.save(saving);
    }

    public Student update(Integer number, String name, String email) {
        if (!studentRepository.existsByNumber(number)) {
            throw new IllegalStateException("Student with number " + number + " does not exist.");
        }
        Student student = studentRepository.findByNumber(number);

        if (name != null && name.length() > 0 && !name.equals(student.getName())) {
            student.setName(name);
        }

        if (email != null && email.length() > 0 && email.equals(student.getEmail())) {
            student.setEmail(email);
        }

        return studentRepository.save(student);
    }

    public Student updateNumber(String id, Integer number) {
        if (!studentRepository.existsById(id)) {
            throw new IllegalStateException("Student with id " + id + " does not exist.");
        }
        Student student = studentRepository.findById(id).orElseThrow();

        if (studentRepository.existsByNumber(number)) {
            throw new IllegalStateException("Student with number " + number + " is already taken.");
        }

        List<String> courses = student.getEnrolledCourses();
        for (String s : courses) {
            Course course = courseRepository.findByCode(s);
            List<Integer> students = course.getStudents();
            students.remove(student.getNumber());
            students.add(number);
            courseRepository.save(course);
        }

        Department department = departmentRepository.findByName(student.getDepartment());
        List<Integer> students = department.getStudents();
        students.remove(student.getNumber());
        students.add(number);
        department.setStudents(students);
        departmentRepository.save(department);

        Faculty faculty = facultyRepository.findByName(department.getFacultyName());
        List<Integer> students2 = faculty.getStudents();
        students2.remove(student.getNumber());
        students2.add(number);
        faculty.setStudents(students2);
        facultyRepository.save(faculty);

        student.setNumber(number);

        return studentRepository.save(student);
    }

    public String delete(Integer number) {
        if (!studentRepository.existsByNumber(number)) {
            return "Student with number " + number + "does not exist";
        }
        Student student = studentRepository.findByNumber(number);

        List<String> courses = student.getEnrolledCourses();
        for (String s : courses) {
            Course course = courseRepository.findByCode(s);
            List<Integer> students = course.getStudents();
            students.remove(student.getNumber());
            courseRepository.save(course);
        }

        Department department = departmentRepository.findByName(student.getDepartment());
        List<Integer> students = department.getStudents();
        students.remove(student.getNumber());
        department.setStudents(students);
        departmentRepository.save(department);

        Faculty faculty = facultyRepository.findByName(department.getFacultyName());
        List<Integer> students2 = faculty.getStudents();
        students2.remove(student.getNumber());
        faculty.setStudents(students2);
        facultyRepository.save(faculty);

        studentRepository.deleteByNumber(number);

        return "Student with number " + number + " is successfully deleted.";
    }

    public List<Course> getCourses(Integer number) {
        Student student = studentRepository.findByNumber(number);
        List<Course> courses = new ArrayList<>();

        for (String s : student.getEnrolledCourses()) {
            courses.add(courseRepository.findByCode(s));
        }

        return courses;
    }

    public List<CompletedCourse> getCompletedCourses(Integer number) {
        Student student = studentRepository.findByNumber(number);
        List<CompletedCourse> courses = new ArrayList<>();

        for (String s : student.getCompletedCourses()) {
            courses.add(completedCourseRepository.findById(s).orElseThrow());
        }

        return courses;
    }

    public String addCompletedCourse(Integer studentNumber, String courseCode) {
        Student student = studentRepository.findByNumber(studentNumber);
        Course course = courseRepository.findByCode(courseCode);

        List<Note> notes = noteRepository.findAllByStudentNumber(studentNumber);
        Note note = null;
        for (Note note1 : notes) {
            if (note1.getCourseCode().equals(courseCode)) {
                note = note1;
                break;
            }
        }

        if (student != null && course != null && note != null) {

            CompletedCourse completedCourse = CompletedCourse.builder()
                    .id(UUID.randomUUID().toString())
                    .code(course.getCode())
                    .name(course.getName())
                    .credit(course.getCredit())
                    .studentID(student.getId())
                    .letterNote(note.getLetterNote())
                    .note(note.getCourseNote())
                    .build();
            completedCourseRepository.save(completedCourse);

            List<String> courses = student.getCompletedCourses();
            courses.add(completedCourse.getId());
            student.setCompletedCourses(courses);
            studentRepository.save(student);

            return "The course which code is " + courseCode + " is added to completed courses of student " + studentNumber;
        }
        if (note == null) {
            return "Note not found.";
        }

        return "Student with number " + studentNumber + " or  course with code " + courseCode
                + " or both are not exist. Process is failed.";
    }

}
